Reem Kufi is a Fatimid-style decorative [Kufic](https://en.wikipedia.org/wiki/Kufic) typeface, as seen in the historical mosques of Cairo. It is largely based on the Kufic designs of the late master of Arabic calligraphy, [Mohammed Abdul Qadir](https://ar.wikipedia.org/wiki/%D9%85%D8%AD%D9%85%D8%AF_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D9%82%D8%A7%D8%AF%D8%B1_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D9%84%D9%87_%28%D8%AE%D8%B7%D8%A7%D8%B7%29), who revived this art in the 20th century and formalized its rules.

Reem Kufi is particularly suitable for display settings, in titles or decorations. Due to its unmistakable old Kufic style, it gives a feeling of something old, historical, or Islamic.

The Arabic component was designed by Khaled Hosney, who combined it with the Latin component by Santiago Orozco. Reem is an Arabic female name that literally means “a white deer,” and is also the name of Khaled's daughter.

To contribute, see [github.com/alif-type/reem-kufi](https://github.com/alif-type/reem-kufi)